package erros;

public class Matematica {

    public void divisao(int numeroA, int numeroB) throws Exception{        
            System.out.println(numeroA / numeroB);        
    }
    
}
